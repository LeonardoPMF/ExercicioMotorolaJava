package br.com.motorola.models;

public class Celular extends Telefone {

	private int alturaDaTelaMoreira;

	public int getAlturaDaTelaMoreira() {
		return alturaDaTelaMoreira;
	}

	public void setAlturaDaTelaMoreira(int alturaDaTelaMoreira) {
		this.alturaDaTelaMoreira = alturaDaTelaMoreira;
	}

	public int getLarguraDaTelaMoreira() {
		return larguraDaTelaMoreira;
	}

	public void setLarguraDaTelaMoreira(int larguraDaTelaMoreira) {
		this.larguraDaTelaMoreira = larguraDaTelaMoreira;
	}

	private int larguraDaTelaMoreira;
}
