// Leonardo Poschardt Moreira de Faria

package br.com.motorola.models;

public class Telefone {

	private String modeloMoreira;
	private int pesoMoreira;

	public String getModeloMoreira() {
		return modeloMoreira;
	}

	public void setModeloMoreira(String modeloMoreira) {
		this.modeloMoreira = modeloMoreira;
	}

	public int getPesoMoreira() {
		return pesoMoreira;
	}

	public void setPesoMoereira(int pesoMoreira) {
		this.pesoMoreira = pesoMoreira;
	}

}
