package br.com.motorola.testes;

import java.sql.Connection;
import java.util.ArrayList;
import br.com.motorola.conexao.Conexao;
import br.com.motorola.dao.CelularDAO;
import br.com.motorola.models.Celular;

public class ProgramaSelecionar {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

Connection con = Conexao.abrirConexao();
	
		CelularDAO celulardao = new CelularDAO(con);
		
		ArrayList<Celular> lista = celulardao.selecionar(); 
		
		if (lista != null) {
			for (Celular p : lista) {
			System.out.println("Modelo do celular : " + p.getModeloMoreira());
			System.out.println("Peso do celular : "+ p.getPesoMoreira());
			System.out.println("Altura da tela do celular : " + p.getAlturaDaTelaMoreira());
			System.out.println("Largura da tela do celular : " + p.getLarguraDaTelaMoreira());
			}
		}
		
		Conexao.fecharConexao(con);
	}

}
