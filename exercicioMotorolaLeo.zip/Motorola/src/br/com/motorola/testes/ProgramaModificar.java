package br.com.motorola.testes;

import java.sql.Connection;

import javax.swing.JOptionPane;

import br.com.motorola.conexao.Conexao;
import br.com.motorola.dao.CelularDAO;
import br.com.motorola.models.Celular;

public class ProgramaModificar {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

Connection con = Conexao.abrirConexao();
		
		Celular celular = new Celular();
		
		CelularDAO celulardao = new CelularDAO(con);
		
		celular.setModeloMoreira(JOptionPane.showInputDialog("Informe o novo modelo."));
		celular.setPesoMoereira(Integer.parseInt(JOptionPane.showInputDialog("Informe o peso do celular a ser alterado.")));
		
		System.out.println(celulardao.alterar(celular));
		
		Conexao.fecharConexao(con);
	}

}
