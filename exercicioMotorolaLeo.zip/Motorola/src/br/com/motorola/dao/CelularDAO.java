package br.com.motorola.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import br.com.motorola.models.Celular;

public class CelularDAO {

	private Connection con;

	public Connection getCon() {
		return con;
	}
	public void setCon(Connection con) {
		this.con = con;
	}
	public CelularDAO() {
	}
	public CelularDAO(Connection con) {
		setCon(con);
	}
	
	public String inserir(Celular celular) {
		String sql = "insert into Celular(modeloMoreira, pesoMoreira, alturaDaTelaMoreira, larguraDaTelaMoreira) values (?,?,?,?)";
		try {
			PreparedStatement ps = getCon().prepareStatement(sql);
			ps.setString(1, celular.getModeloMoreira());
			ps.setInt(2, celular.getPesoMoreira());
			ps.setInt(3, celular.getAlturaDaTelaMoreira());
			ps.setInt(4, celular.getLarguraDaTelaMoreira());
			if (ps.executeUpdate() > 0) {
				return "Inserido com sucesso";
			} else {
				return "Erro ao inserir";
			}
		} catch (SQLException e) {
			return	e.getMessage();
		}
	}
	
	public String deletar(Celular celular) {
		String sql = "delete from Celular where pesoMoreira = (?)";
		try {
			PreparedStatement ps = getCon().prepareStatement(sql);
			ps.setInt(1, celular.getPesoMoreira());
			if (ps.executeUpdate() > 0) {
				return "Deletado com sucesso!";
			}
			else {
				return "Erro ao deletar!";
			}
		} catch (SQLException e) {
			return e.getMessage();
		}
	}
	
	public String alterar(Celular celular) {
		String sql = "update Celular set modeloMoreira = (?) where pesoMoreira = (?)";
		try {
			PreparedStatement ps = getCon().prepareStatement(sql);
			ps.setString(1, celular.getModeloMoreira());
			ps.setInt(2, celular.getPesoMoreira());
			if (ps.executeUpdate() > 0) {
				return "Alterado com sucesso!";
			}
			else {
				return "Erro ao alterar!";
			}
		} catch (SQLException e) {
			return e.getMessage();
		}
	}
	
	public ArrayList<Celular> selecionar() {
		String sql = "select * from Celular";
		ArrayList<Celular> retornarCelular = new ArrayList<Celular>() ;
		try {
			PreparedStatement ps = getCon().prepareStatement(sql);
			ResultSet rs =ps.executeQuery();
			if (rs != null) {
				while (rs.next()) {
				Celular celular = new Celular();
				celular.setModeloMoreira(rs.getString(1));
				celular.setPesoMoereira(0);
				celular.setAlturaDaTelaMoreira(3);
				celular.setLarguraDaTelaMoreira(0);
				retornarCelular.add(celular);
				}
				return retornarCelular;
			}
			else {
				return null;
			}
		} catch (SQLException e) {
			return null;
		}
	}
	
	
	
	
	
	
}
